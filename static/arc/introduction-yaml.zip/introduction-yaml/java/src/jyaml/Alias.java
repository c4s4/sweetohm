package jyaml;

import java.io.File;
import org.ho.yaml.Yaml;

public class Alias {
    
    public static void main(String[] args)
        throws Exception {
        Personne[] personnes = Yaml.loadType(new File("test/alias.yml"),
                                             Personne[].class);
        for(int i=0; i<personnes.length; i++) {
            Personne personne = personnes[i];
            System.out.println(personne);
        }
        // on teste que les références sont bien identiques
        System.out.println("Ancre OK: "+(personnes[2].getParents()[0]==personnes[0]));
    }

}
