Singleton
=========

Voici un bout de code java très utile lorsqu’on souhaite qu’une application ne
puisse tourner qu’en un seul exemplaire sur une machine.

Pour ce faire, il suffit d’ouvrir un port en écoute. c’est beaucoup plus
efficace que des fichiers de lock car lorsque l’application se termine, le port
est libéré par l’OS, même si l’application a planté.

```java
private void ensureSingleInstance() {
    try {
        final ServerSocket socket = new ServerSocket(12345, 10, InetAddress.getLocalHost());
        System.out.println("Le serveur est la seule instance, on continue");
        Thread instanceListenerThread = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    try {
                        socket.accept();
                    } catch (IOException e) {
                        // do nothing
                    }
                }
            }
        });
        instanceListenerThread.start();
    } catch(Exception e) {
        System.out.println("Une autre instance du serveur tourne, arrêt");
        System.exit(1);
    }
}
```

Build
-----

Pour avoir de l'aide sur le build :

    make

Pour compiler les sources Java :

    make compile

Pour lancer l'application :

    make run

Pour nettoyer les fichiers générés :

    make clean

*Enjoy!*
