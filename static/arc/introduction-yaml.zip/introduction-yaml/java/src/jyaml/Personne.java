package jyaml;

public class Personne {
    
    private String nom;
    private int age;
    private Personne[] parents;
    
    public String getNom() {
        return nom;
    }
    
    public void setNom(String nom) {
        this.nom = nom;
    }
    
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
    
    public Personne[] getParents() {
        return parents;
    }
    
    public void setParents(Personne[] parents) {
        this.parents = parents;
    }
    
    public String toString() {
        StringBuffer buffer = new StringBuffer("[Personne nom='")
            .append(nom)
            .append("', age='")
            .append(age)
            .append(", parents='");
        if (parents!=null) {
            for (int i = 0; i < parents.length; i++) {
                Personne parent = parents[i];
                buffer.append(parent.toString());
                if (i < parents.length-1) buffer.append(", ");
            }
        }
        buffer.append("]");
        return buffer.toString();
    }

}
