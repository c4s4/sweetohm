package test;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

public class Main {

    public static void main(String[] args) {
        Main main = new Main();
        System.out.println("version: " + main.getVersion());
    }

    /**
     * Return version extracted from MANIFEST.
     *
     * @return The server version as a String.
     */
    private String getVersion() {
        try {
            Enumeration<URL> resources = this.getClass().getClassLoader().getResources("META-INF/MANIFEST.MF");
            while (resources.hasMoreElements()) {
                try {
                    Manifest manifest = new Manifest(resources.nextElement().openStream());
                    Attributes attributes = manifest.getMainAttributes();
                    String name = attributes.getValue("Implementation-Title");
                    // this name must be the same as <name> field of the POM
                    if ("test".equals(name)) {
                        String version = attributes.getValue("Implementation-Version");
                        if (version != null) {
                            return version;
                        } else {
                            return "UNKNOWN";
                        }
                    }
                } catch (IOException E) {
                    // do nothing
                }
            }
        } catch(Exception e) {
            // do nothing
        }
        return "UNKNOWN";
    }
}
