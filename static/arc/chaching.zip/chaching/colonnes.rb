#!/usr/bin/env ruby
# Script affichant le nom et le type des colonnes de la tables ChaChing

require 'sqlite3'

# le fichier de la base de donn�es ChaChing
DATABASE = File.expand_path '~/Library/Application Support/Cha_Ching/Cha_Ching.1ccdb'

# la liste des colonnes
colonnes = []

# affiche le nom et le type des colonnes de la table ChaChing
begin
  db = SQLite3::Database.new(DATABASE)
  query = "SELECT * FROM ZTRANSENTITY"
  db.query(query) do |result|
    noms = result.columns
    types = result.types
    0.upto(noms.length-1) do |index|
      colonnes << { :name => noms[index], :type => types[index] }
    end
  end
ensure
  db.close
end

LIGNE = 40

# affiche une ligne
def ligne(nom, type)
  puts nom + ' ' + '.'*(LIGNE - (nom.length + type.length + 2)) + ' ' + type
end

# on les noms et types des colonnes
for colonne in colonnes
  ligne colonne[:name], colonne[:type]
end
