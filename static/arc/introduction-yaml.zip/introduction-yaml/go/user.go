package main

import (
	"fmt"
	"gopkg.in/yaml.v2"
	"io/ioutil"
	"os"
)

type User struct {
	Name string
	Age  int
}

func main() {
	filename := os.Args[1]
	var user User
	source, err := ioutil.ReadFile(filename)
	if err != nil {
		panic(err)
	}
	err = yaml.Unmarshal(source, &user)
	if err != nil {
		panic(err)
	}
	fmt.Printf("User: %#v\n", user)
}
