#!/usr/bin/env ruby
# Script affichant les comptes ChaChing

require 'sqlite3'

# le fichier de la base de donn�es ChaChing
DATABASE = File.expand_path '~/Library/Application Support/Cha_Ching/Cha_Ching.1ccdb'

# les balances des comptes
balances = {}

# r�cup�re les donn�es dans la base
begin
  db = SQLite3::Database.new(DATABASE)
  query = "SELECT ZTRANS_AMOUNT,ZTRANS_ACCOUNTID FROM ZTRANSENTITY"
  db.execute(query) do |row|
    value = row[0].to_f
    account = row[1]
    balances[account] = 0.0 if not balances.keys.include?(account)
    balances[account] += value
  end
ensure
  db.close
end

# on affiche la liste des comptes et leur balance
for compte in balances.keys
  puts "Compte #{compte}: #{"%.2f" % balances[compte]}"
end
