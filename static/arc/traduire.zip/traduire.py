#!/usr/bin/env python
# coding=UTF-8
#
# It may be necessary to add URL parameter 'key=xxx' with your Google API key
# for this script to work properly for great number of calls.

import sys
import json
import getopt
import urllib
import urllib2
import HTMLParser

HELP = """Usage: traduire [-h] [-s source] [-t target] phrase à traduire
-h         Afficher cette page d'aide.
-s source  Langue source (au format ISO 'fr', 'en'.. 'en' par défaut).
-t target  Langue target (au format ISO 'fr', 'en'.. 'fr' par défaut)."""

URL = 'https://ajax.googleapis.com/ajax/services/language/translate' + \
      '?v=1.0&q=%(text)s&langpair=%(source)s%%7C%(target)s'

def translate(source, target, text):
    url    = URL % {
        'source': source,
        'target': target,
        'text'  : urllib.quote(text),
    }
    request = urllib2.Request(url)
    response = urllib2.urlopen(request)
    structure = json.loads(response.read())
    status = structure['responseStatus']
    if status == 200:
        translation = structure['responseData']['translatedText']
        return HTMLParser.HTMLParser().unescape(translation)
    else:
        return 'ERROR: %s' % structure['responseDetails']

# parse command line
if __name__ == '__main__':
    source = 'en'
    target = 'fr'
    text   = None
    try:
        OPTS, ARGS = getopt.getopt(sys.argv[1:],
                                   'hs:t:',
                                   ['help', 'source', 'target'])
    except getopt.GetoptError, error:
        print 'ERROR: %s' % str(error)
        print HELP
        sys.exit(1)
    for OPT, ARG in OPTS:
        if OPT == '-h':
            print HELP
            sys.exit(0)
        elif OPT == '-s':
            source = ARG
        elif OPT == '-t':
            target = ARG
        else:
            print 'Unhandled option: %s' % OPT
            print HELP
            sys.exit(1)
    text = ' '.join(ARGS)
    print translate(source, target, text)
