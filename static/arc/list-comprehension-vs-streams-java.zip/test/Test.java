import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.stream.Collectors;

class Invoice {

    private static int nextId = 0;

    private int id;
    private String title;
    private double amount;

    public Invoice(String title, double amount) {
        this.id = Invoice.nextId++;
        this.title = title;
        this.amount = amount;
    }

    public String toString() {
        return String.format("<invoice id='%d' title='%s' amount='%f'",
                             this.id, this.title, this.amount);
    }

    public int getId() {
        return this.id;
    }

    public String getTitle() {
        return this.title;
    }

    public double getAmount() {
        return this.amount;
    }

}

public class Test {

    public static void main(String[] argv) {
        Test test = new Test();
        test.run();
    }

    public void run() {
        ArrayList<Invoice> invoices = new ArrayList<Invoice>();
        invoices.add(new Invoice("Training 1", 1.0));
        invoices.add(new Invoice("Training 2", 2.0));
        invoices.add(new Invoice("Training 3", 3.0));
        invoices.add(new Invoice("Test 4", 4.0));
        invoices.add(new Invoice("Test 5", 5.0));
        Collections.shuffle(invoices);
        System.out.println(invoices);
        List<Integer> invoiceIds = 
            invoices.stream()
            .filter(inv -> inv.getTitle().contains("Training"))
            .sorted(Comparator.comparingDouble(Invoice::getAmount).reversed())
            .map(Invoice::getId)
            .collect(Collectors.toList());
        System.out.println(invoiceIds);
     }

}
