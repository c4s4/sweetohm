package main

import (
	"fmt"
	"gopkg.in/yaml.v2"
	"io/ioutil"
	"os"
)

func main() {
	filename := os.Args[1]
	var thing interface{}
	source, err := ioutil.ReadFile(filename)
	if err != nil {
		panic(err)
	}
	err = yaml.Unmarshal(source, &thing)
	if err != nil {
		panic(err)
	}
	fmt.Printf("Thing: %#v\n", thing)
}
