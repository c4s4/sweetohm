#!/usr/bin/env python

import random


class Invoice:

    id = 0

    def __init__(self, title, amount):
        self.id = self.__class__.id
        self.__class__.id += 1
        self.title = title
        self.amount = amount

    def __repr__(self):
        return "<invoice id='%s' title='%s' amount='%s'>" % \
            (self.id, self.title, self.amount)


invoices = [
    Invoice("Training 1", 1.0),
    Invoice("Training 2", 2.0),
    Invoice("Training 3", 3.0),
    Invoice("test 4", 4.0),
    Invoice("test 5", 5.0),
]

random.shuffle(invoices)
print invoices
invoice_ids = [i.id for i in
               sorted(invoices, key=lambda i: i.amount, reverse=True)
               if "Training" in i.title]
print invoice_ids
