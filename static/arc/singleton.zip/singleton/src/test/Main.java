package test;

import java.io.IOException;
import java.net.ServerSocket;

public class Main {

    private static final int PORT = 12345;

    public static void main(String[] args) throws Exception {
        Main main = new Main();
        main.start();
    }

    private void start() throws InterruptedException {
        ensureSingleInstance();
        Thread.sleep(60000);
    }

    private static void ensureSingleInstance() {
        try {
            final ServerSocket socket = new ServerSocket(PORT);
            System.out.println("Le serveur est la seule instance, on continue");
            Thread thread = new Thread(new Runnable() {
                public void run() {
                    while (true) {
                        try {
                            socket.accept();
                        } catch (IOException e) {
                            // do nothing
                        }
                    }
                }
            });
            thread.setDaemon(true);
            thread.start();
        } catch(Exception e) {
            System.out.println("Une autre instance du serveur tourne, arrêt");
            System.exit(1);
        }
    }

}
