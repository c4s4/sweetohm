To run this sample :

    mvn clean package exec:exec


